# Ansible Collection - escrimaglia.o4n

## Documentation for the collection

Ansible modules for Oction Automation framework

# Octupus Collection

Collection o4n_dev_git helps developers to work with Gite Repositories.
By Ed Scrimaglia

## Required

Ansible >= 2.10  

## Modules

- o4n_git_set_remote  
  Set Git remote on any directory  

- o4n_git_import  
  import selected files from a Git repository  
